Adminizio Lite 1.0
downloaded from www.adminizio.com

LICENCE:
================================================================================

    * For non-commercial use only
    * This version has no technical support

GET ADMINIZIO UNLIMITED!
================================================================================

    Only for $50!
    Visit www.adminizio.com
    
    Adminizio makes your job on every new website project radically easier.
    From now on, you will not waste your time on coding of XHTML templates for
    administration, you will not waste your time on Photoshop, drawing your
    icons, and you will not fly off the handle, when your templates look
    different in Firefox and in Internet Explorer 6. The templates were designed
    on the basis of our long-term experience with the website application
    development. We have tried to create well-arranged, elegant and easily
    extensible XHTML/CSS templates, which you can take and connect directly
    to your application.
    
    * Templates for Login, Overview, Calendar, Photogallery, Forms, User...
    * Unlimited licence for using
    * Unlimited editing
    * Lifelong updates for free
    
    One payment = unlimited number of projects + lifelong updates for free
    